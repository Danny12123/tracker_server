
module.exports = {
    firebaseConfig : {
        apiKey: "AIzaSyDg1-ehhtvJoFCp7VLhlUK_FebN7KAQqrI",
        authDomain: "trackexp-e9668.firebaseapp.com",
        projectId: "trackexp-e9668",
        storageBucket: "trackexp-e9668.appspot.com",
        messagingSenderId: "131651296625",
        appId: "1:131651296625:web:fdf808f9394491fffaead0"
}
}